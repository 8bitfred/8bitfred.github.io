---
layout: page
title: Fred History
nav_order: 2
lang: en
ref: history
permalink: /en/history/
---

<p align="center">
  <img src="{{ '/assets/images/MadeInSpain/Polaroid2.jpg' | relative_url }}" width="400"><br>
  <sub>From left to right: Cela, Granados, Menéndez and Rada. Input Sinclair, Madrid (Spain), February 1986.</sub>
</p>

[*Fred*](https://worldofspectrum.org/archive/software/games/fred-investronica-sa) is an action video game developed by [Carlos Granados (Charlie)](https://amstrad.es/doku.php?id=programadores:carlos_granados_charlie), [Fernando Rada](https://es.wikipedia.org/wiki/Fernando_Rada) and [Paco Menéndez](https://en.wikipedia.org/wiki/Paco_Men%C3%A9ndez) for the Sinclair ZX Spectrum in 1983, and published by [Indescomp, SA](https://es.wikipedia.org/wiki/Indescomp) in Spain and by [Quicksilva, Ltd](https://en.wikipedia.org/wiki/Quicksilva) in the UK, with cover art by [David Rowe](https://www.davidrowe.net/). Versions for Commodore 64 and Amstrad CPC 464 were released throughout 1984.

*Fred* incorporates elements—such as procedural maze generation, exploration, resource management, and high difficulty— that align with features later associated with [roguelike](https://en.wikipedia.org/wiki/Rogue_(video_game)) games.

It is considered one of the earliest video games developed in Spain for the Sinclair ZX Spectrum, along with its contemporary [*Bugaboo (The Flea)*](https://en.wikipedia.org/wiki/Bugaboo_(The_Flea)). Although an agreement was reached with Quicksilva to market both titles in the United Kingdom in the autumn of 1983, they were released a few weeks apart: at the end of that year and the beginning of 1984, respectively. Both were major commercial successes in Spain (distributed by [Investrónica, SA](https://es.wikipedia.org/wiki/Investr%C3%B3nica)) and the UK (distributed by Quicksilva, Ltd).

A conversion for the Amstrad CPC, written by the same team including [Camilo Cela](https://www.devuego.es/bd/fdesarrollador/camilo-cela), was launched by [Amsoft](https://en.wikipedia.org/wiki/Amsoft) as [*Roland on the Ropes*](https://www.cpcwiki.eu/index.php/Roland_on_the_Ropes) in the spring of 1984, as part of the [Roland](https://en.wikipedia.org/wiki/Roland_(game_character)) video game series. Interestingly, [Alan Sugar](https://en.wikipedia.org/wiki/Alan_Sugar) (Amstrad’s CEO) named the character after [Roland Perry](https://amstrad.com/about-us/) (engineer in charge of the development of the CPC 464) while playing a demo of *Fred*. The Commodore 64 version was developed by [Pedro Ruiz](https://www.devuego.es/bd/fdesarrollador/pedro-ruiz), a member of Indescomp's programming team. 

The history of *Fred* starts when Granados played the game [Pengo](https://en.wikipedia.org/wiki/Pengo_(video_game)) at an arcade during the summer of 1983. In Pengo the player controls a penguin that must move or destroy ice blocks in a maze to kill enemies and find the exit. At the beginning of each level the maze [is generated randomly](https://www.youtube.com/watch?v=6q3bNHvj92c) in front of the user. Charlie, who had just graduated high school and was about to
start his Physics degree, was fascinated by the maze generation, and challenged himself to write a similar algorithm in his Spectrum computer. He quickly completed it, and had the idea that the random maze could be used for a video-game.

After his summer vacation Charlie got together with his friends, Fernando and Paco, and they set the basis for the game: the goal would be to exit the maze; the main character would be an adventurer, like Indiana Jones, with a gun to fight the enemies; and the setting, a pyramid. They completed the game in just a few weeks.

*Fred* received very positive reviews by the specialized press. Crash Magazine ([issue 3, p84]({{ '/assets/magazines/Crash03-Apr84-p84.pdf' | relative_url }})) gave it a score of 83%, noting *"The game has great animation, especially that of Fred himself, and the graphics are generally excellent. Even Fred's revolver recoils when it is fired"*. Your Computer ([April 1984 issue]({{ '/assets/magazines/YourComputer_1984_04-p59.pdf' | relative_url }})) gave it 4 out of 5 stars, and described it as a *"feast of Disneyesque graphics"*. Your Spectrum ([issue 3, p70]({{ '/assets/magazines/YourSpectrum03-May84-p70.pdf' | relative_url }})) scored it 8 out of 10. And it got a 100% score on Home Computing Weekly ([issue 52, p22]({{ '/assets/magazines/Home_Computing_Weekly_052-p22.pdf' | relative_url }})).

After *Fred*, its authors founded the game studio Made in Spain and the distributor [Zigurat](https://en.wikipedia.org/wiki/Zigurat_(company)). They produced a long list of games for 8 and 16 bit platforms, and even a few arcade titles.
