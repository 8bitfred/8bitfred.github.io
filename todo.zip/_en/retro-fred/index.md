---
layout: page
title: Retro-Fred Project
nav_order: 5
has_children: true
has_toc: true
lang: en
ref: retro-fred
permalink: /en/retro-fred/
---


<p align="center">
  <img src="{{ '/assets/images/FredBanner/FredBanner_retrofred.png' | relative_url }}" width="300">
</p>

<p style="text-align: center; font-size: 18px; font-family: 'Times New Roman', serif;">
  T U · Q U O Q U E · P R I M U S · F U I S T I<br>
  2021 -- 2026
</p>

*Retro-Fred* aims to faithfully bring *Fred* to modern platforms through reverse engineering of the original Zilog Z80 code.



