---
layout: page
title: C++ and Scratch
parent: Retro-Fred Project
nav_order: 1
has_toc: true
lang: en
ref: c++andscratch
permalink: /en/retro-fred/ports
---

Retro-Fred in C++ (2021-2024)
-----------------------------
<sub>by Miguel Catalina</sub>

A conversion of Fred to C++ using SDL. It runs on Linux, Windows,
MacOS, iOS and Android.

* [Source code in GitHub](https://github.com/8bitfred/retro-fred)
* [Releases](https://github.com/8bitfred/retro-fred/releases)
* [Google Play Store](https://play.google.com/store/apps/details?id=com.eightbitfred.retro_fred&hl=en)
* [App Store](https://apps.apple.com/us/app/retro-fred/id6738402036)


Retro-Fred in Scratch (2021-2024)
---------------------------------
<sub>by Alfredo Catalina</sub>

Conversion of Fred to Scratch.

* [Scratch page](https://scratch.mit.edu/projects/1053158449)
* [Source code in GitHub](https://github.com/8bitfred/retro-fred-scratch)
* [Releases](https://github.com/8bitfred/retro-fred-scratch/releases)
* [Book](/en/retro-fred/documentation/book)
* [Diagrams](/en/retro-fred/documentation/diagrams)
* [Code in PDF and SVG](/en/retro-fred/documentation/scratchcode)
* [Sprites and audio](/en/retro-fred/documentation/resources)
* [Variables](/en/retro-fred/documentation/scratchvariables)

Retro-Fred's Early Projects (1993-1994)
-------------------------

<div style="overflow-x:auto;">
  <div style="display:inline-block;">
    <table style="border-collapse: collapse;">
      <tr>
        <td align="center">
          <a href="fredpc">
            <img src="/assets/images/FredPC/Captura_01.jpg" width="150">
          </a>
        </td>
        <td align="left">
          1993<br>
          MSDOS<br>
          <a href="fredpc">Snapshots</a>
        </td>
      </tr>
      <tr>
        <td align="center">
          <a href="fredhp48">
            <img src="/assets/images/FredHP48/Captura_04.png" width="150">
          </a>
        </td>
        <td align="left">
          1994<br>
          HP48<br>
          <a href="fredhp48">Snapshots</a>
        </td>
      </tr>
    </table>
  </div>
</div>